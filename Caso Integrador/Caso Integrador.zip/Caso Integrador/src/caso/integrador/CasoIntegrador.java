/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package caso.integrador;

import com.sun.source.tree.SwitchExpressionTree;
import javax.swing.JOptionPane;

/**
 *
 * @author Aulas Heredia
 */
public class CasoIntegrador {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int opcion = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de productos que desea ingresar: "));
        Producto producto1[] = new Producto[opcion];
        burnMethod();
        

    }

    public static void burnMethod() {
        JOptionPane.showMessageDialog(null, "***** Bienvenido al sistema de inventario del supermercado Super Chinese ***** \n"
                + "*** Código de SuperMercado: 203575 ***");
    }
    
    public static void setData(Producto[] array) {
        Producto.setEmployeeName(JOptionPane.showInputDialog("Ingrese el nombre del bodeguero que ingresa el producto: "));
        Producto.setEmployeeId(Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cédula del bodeguero que ingresa el producto: ")));
        JOptionPane.showMessageDialog(null, "Se solicitarán los datos para ingresar los productos: ");
        for (int i = 0; i < array.length; i++) {
            int productCode = Integer.parseInt(JOptionPane.showInputDialog("Digite el código del producto: "));
            String productName = JOptionPane.showInputDialog("Ingrese el nomnre del producto: ");
            int productQuantity = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de productos que desea almacenar: "));
            double basePrice = Double.parseDouble(JOptionPane.showInputDialog("Digite el precio base del producto: "));
            int productType = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el tipo de producto que desea almacenar teniendo en cuenta lo siguiente: \n"
                    + "1. Alimentos \n"
                    + "2. Bebidas \n"
                    + "3. Higiene \n"
                    + "4. Limpieza"));
            array[i] = new Producto(productCode, productName, productQuantity, basePrice, productType, basePrice, basePrice)
        }
    }

}
