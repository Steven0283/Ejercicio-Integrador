/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clase10;

/**
 *
 * @author Aulas Heredia
 */
public class Calificacion {
    private String name;
    private String course;
    private int grade;

    public Calificacion() {
    }

    public Calificacion(String name, String course, int grade) {
        this.name = name;
        this.course = course;
        this.grade = grade;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    @Override
    public String toString() {
        return "Califiacion{" + "Nombre: " + name + ", Curso: " + course + ", Nota obtenida: " + grade + '}';
    }
    
    
}
