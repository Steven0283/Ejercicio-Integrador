/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase10;

import javax.swing.JOptionPane;

/**
 *
 * @author Aulas Heredia
 */
public class Clase10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Calificacion calificacion1[] = new Calificacion[5];

    }

    public static void setData(Calificacion[] array) {
        for (int i = 0; i < array.length; i++) {
            JOptionPane.showMessageDialog(null, "Se solicitarán los datos del estudiante #" + (i + 1));
            String name = JOptionPane.showInputDialog("Ingrese el nombre del estudiante: ");
            String course = JOptionPane.showInputDialog("Ingrese el nombre del curso: ");
            int grade = Integer.parseInt(JOptionPane.showInputDialog("Digite la nota obtenida del estudiante en este curso: "));
            array[i] = new Calificacion(name, course, grade);
        }

    }

    public static void printData(Calificacion[] array) {
        for (int i = 0; i < array.length; i++) {
            JOptionPane.showMessageDialog(null, "Los datos del estudiante " + (i + 1) + " son: \n"
                    + "Nombre: " + array[i].getName() + "\n"
                    + "Nombre del curso: " + array[i].getCourse() + " \n"
                    + "Nota obtenida: " + array[i].getGrade());
        }

    }
    
    public static void bubble(Calificacion)

}
